Krótki Opis moda:
Mod dubluje wszystkie trasy Pełnej Swobody i usuwa upomnienia i nerwy instruktora.
Instuktor pełni funkcję tylko nawalonego kumpla passarzera

Instalacja moda:
1. Wypakuj pliki z archiwum zip
2. Zrób Backup gry (lub samych folderów: "Config" i "Missions" z folderu gry)
3. Skopiuj folder "Mission" z folderu moda
4. Wklej ten folder do Lokalizacji gry i kliknij"Zamień plik w miejscu docelowym"
5. Otwórz folder "Config" w lokalizacji gry
6. Otwórz za pomocą Notatnika plik "Content.txt" oraz wklej:

ITEM	MISSION	"&MT_FreeRide00_no&" 0
ITEM	MISSION	"&MT_FreeRide01_no&" 0
ITEM	MISSION	"&MT_FreeRide02_no&" 0
ITEM	MISSION	"&MT_FreeRide03_no&" 0
ITEM	MISSION	"&MT_FreeRide04_no&" 0
ITEM	MISSION	"&MT_FreeRide05_no&" 0
ITEM	MISSION	"&MT_FreeRide06_no&" 0

w miejscu na wzór jak jest to zrobione w przykładzie pliku "Content.txt" w folderze "Config" moda

7. Zrób to samo z linijkami:

UNLOCKED "&MT_FreeRide00_no&"
UNLOCKED "&MT_FreeRide01_no&"
UNLOCKED "&MT_FreeRide02_no&"
UNLOCKED "&MT_FreeRide03_no&"
UNLOCKED "&MT_FreeRide04_no&"
UNLOCKED "&MT_FreeRide05_no&"
UNLOCKED "&MT_FreeRide06_no&"

tak jak w przykładzie pliku "Content.txt" w folderze "Config" moda
8. Wróć do folderu "Config" gry i otwórz plik "text.txt" i wklej do niego:

MT_FreeRide00_no	"Przejażdżka po centrum bez instruktora"
MT_FreeRide01_no	"W górach bez instruktora"
MT_FreeRide02_no	"Osiedle Millenia bez instruktora"
MT_FreeRide03_no	"Kraków w deszczu bez instruktora"
MT_FreeRide04_no	"Millenia o zachodzie słońca bez instruktora"
MT_FreeRide05_no	"Góry w słonecznym deszczu bez instruktora"
MT_FreeRide06_no	"Jesienne Millenia bez instruktora"

I możesz sprawdzić z przykładem pliku "text.txt" (jak w punkcie 7.)
9. Wklej również do tego pliku:

MI_FreeRide00_no	"Krakowskie śródmieście w piękny, słoneczny dzień. Bez Instruktora"
MI_FreeRide01_no	"Przejażdżka po pięknej górskiej okolicy. Nie rozglądaj się jednak za bardzo tylko patrz na drogę. Bez Instruktora"
MI_FreeRide02_no	"Przekonajmy się jak jeździ się po współczesnym osiedlu mieszkaniowym. Bez Instruktora"
MI_FreeRide03_no	"W Krakowie rozpadało się na dobre, jednak takie warunki to dobra okazja do ćwiczeń. Bez Instruktora"
MI_FreeRide04_no	"Czy spokojne osiedle o zachodzie słońca może oferować jakieś niespodzianki? Bez Instruktora"
MI_FreeRide05_no	"Padający deszcz i mocno świecące słońce? Tak, w górach wszystko może się zdarzyć. Bez Instruktora"
MI_FreeRide06_no	"Jesienna pogoda dotarła w końcu i tutaj. Bez Instruktora"

W odpowiednim miejscu jak w przykładowym pliku "text.txt" moda
10. Uwaga:
	-nie jest to oficjalny dodatek do gry
	-wszystko co robisz, robisz na własną odpowiedzialność
	-mod może nie być kompatybilny z innymi modami
	-mod można zainstalować o wiele łatwiej przy pomocy automatycznego "Instalatora Modów" 
	zawartego w Launcherze SJ2 Revive: https://sj2r.zndev.pl/launcher.php
	-więcej modyfikacji, poradników, narzędzi do modowania i porad dot. Symulatora Jazdy 2
	znajdziesz na stronie naszego projektu SJ2Revive Project: https://sj2r.zndev.pl/

by Qwertyuiop123 (20.01.2023)