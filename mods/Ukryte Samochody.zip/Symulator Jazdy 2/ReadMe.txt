Krótki Opis moda:
Mod dodaje pojazdy ukryte przez developerów gry, prawdopodobnie przez brak czasu ich dokończenia.
Pojazdy: Dacia Logan, Betoniarka, Ambulans, KurierVan.

Instalacja moda:
1. Wypakuj pliki z archiwum zip
2. Zrób Backup gry (lub samych folderów: "Config" i "Cars" z folderu gry)
3. Skopiuj folder "Cars" z folderu moda
4. Wklej ten folder do Lokalizacji gry i kliknij"Zamień plik w miejscu docelowym"
5. Otwórz folder "Config" w lokalizacji gry
6. Otwórz za pomocą Notatnika plik "Content.txt" oraz wklej:

ITEM	CAR		"&Car_logan&"	0
ITEM	CAR		"&Car_van&"	0
ITEM	CAR		"&Car_ambulance&"	0
ITEM	CAR		"&Car_truck_concrete&"	0

w miejscu na wzór jak jest to zrobione w przykładzie pliku "Content.txt" w folderze "Config" moda
7. Wróć do folderu "Config" gry i otwórz plik "text.txt" i wklej (tak aby linijki się nie dublowały z już istniejącymi) do niego:

Car_ambulance		"Ambulans"
Car_truck_concrete	"Betoniarka"
Car_van			"Pojazd dostawczy"
Car_van_b		"Pojazd dostawczy 2"
Car_van_o		"Pojazd dostawczy 3"
Car_logan		"Posazd osobowy 3"

8. Uwaga:
	-nie jest to oficjalna łatka do gry, 
	mimo, że wykorzystuje poprawione elementy z plików gry
	-wszystko co robisz, robisz na własną odpowiedzialność
	-mod może nie być kompatybilny z innymi modami
	-mod można zainstalować o wiele łatwiej przy pomocy automatycznego "Instalatora Modów" 
	zawartego w Launcherze SJ2 Revive: https://sj2r.zndev.pl/launcher.php
	-więcej modyfikacji, poradników, narzędzi do modowania i porad dot. Symulatora Jazdy 2
	znajdziesz na stronie naszego projektu SJ2Revive Project: https://sj2r.zndev.pl/

by Qwertyuiop123 (20.01.2023)