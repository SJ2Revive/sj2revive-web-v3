MOD POBRANY Z  https://sj2r.zndev.pl/getmod.php?id=3

jak zainstalowac:
skopiuj folder "Config" do folderu z SJ2