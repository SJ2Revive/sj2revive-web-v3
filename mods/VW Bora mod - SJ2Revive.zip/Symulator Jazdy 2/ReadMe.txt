INSTRUKCJA INSTALACJI TEGO MODA:
1. Rozpakuj archiwum ZIP
2. Znajdź lokalizację plików gry - folder wyżej od Launchera
3. Wklej Foldery: "Cars" i "media" do lokalizacji swojej gry
 i kliknij "zamień pliki w miejscu docelowym"
4. Otwórz folder moda "Config" i za pomocą Notatnika otwórz plik "Content.txt"i skopiuj
 oraz wklej linijkę: 

ITEM	CAR		"&Car_bora&"	0

 do oryginalnego pliku swojej gry w miejscu na wzór pliku moda
5. Otwórz plik "text.txt" oraz analogicznie (jak w pkt 4.) skopiuj i wklej linijkę:

Car_bora		"Volkswagen Bora MOD" 

(jest to nazwa samochodu pojawiająca się w menu)
6. Otwórz plik "CarDirector.txt" i tak jak poprzednio (jak w pkt 4 i 5), wklej to"

CAR 	"..\Cars\bora.car"

(jest to lokalizacja dla gry do tego, aby mod był spawnowany w AI)
7. Otwórz folder "Sound" z folderu moda i przekopiuj do folderu "Sound" w lokalizacji gry 
pliki dźwiękowe ".wav"
8. Otwórz plik "cars.sg" (który znajduje się w folderze "Sound" gry) za pomocą Notatnika i wklej tam:

ignition_bora		..\Sounds\ignition_bora.wav
engine_bora_idle	..\Sounds\engine_bora_idle.wav
engine_bora_low	..\Sounds\engine_bora_low.wav
engine_bora_high	..\Sounds\engine_bora_high.wav
engine_bora_reverse ..\Sounds\engine_bora_reverse.wav

(Jak w pkt 4, 5 i 6 - Możesz oczywiście skorzystać ze wzoru zmodyfikowanego pliku "cars.sg" w folderze moda > folder "Sound")

OTHER FILES.ZIP:
- Narzędzia potrzebne do zrobienia moda
- Pliki, do modyfikowania tej modyfikacji (Pliki Blendera, Plik Gimpa, Ogre Mesh Downgrade i inne)

LINKI:
 - Oficjalna Strona Projektu - SJ2Revive: https://sj2r.zndev.pl/ - Mody, Launcher, Updaty, Poradniki
 - Ogre Tools:https://www.ogre3d.org/download/tools
 - Ogre Forum: https://forums.ogre3d.org/
 - Aktualizacja do 1.03 (na której testowano tego moda):
 https://www.youtube.com/watch?v=t_CQVoO1BGE - wkrótce również na stronie SJ2Revive
 - Kanały YT Twórców SJRevive (obejrzyj postępy i nowości): 
 https://www.youtube.com/@Qwertyuiop-123 oraz https://www.youtube.com/@zordon3582
 - Dźwięk silnika powstał z modyfikacji moda BeamNG: https://www.beamng.com/resources/old-buzzy-covet-sound-for-ibishu-covet.6266/
 - Gra powstała dzięki FreeMind_pl: https://freemind.games/aktualnosci/

UWAGI:
 - Nie jest to oficjalna zawartość gry
 - Najlepiej przed instalacją moda wykonać Backup całego folderu gry
 - Mod był testowany na wersji 1.03, ale prawdopodonie działa z innymi wersjami
 - Modyfikacja oparta jest na oryginalnym pojezdzie z gry "Renault Logan", lecz nie zamienia go, a jest załkowicie odrębną zawartością
 - Plik nie jest pełną zainstalowaną grą, gdyż kopiowanie gry jest zabronione na mocy praw autorskich
 - Jeśli masz już inne mody, pamiętaj aby dopisywać linijki tekstu w danych plikach jak w instrukcji moda, a nie zamieniać całe pliki w miejscach docelowych,
bo w przeciwnym razie mod może niszczyć wcześniej zainstalowane modyfikacje, nadpisując ich modyfikacje plików!!!
 - Rozprowadzanie tego moda jest zabronione, kopie jego na podejrzanych stronach będą zgłaszane do administratora danej strony,
jedynym źródłem, z którego można to pobrać jest oficjalna strona SJ2Revive: https://sj2r.zndev.pl/ w zakładce "Modyfikacje"
 - Mod posiada niedoskonałości oraz bugi, np. jeśli gra crashuje to prawdopodobnie:
	Mod jest źle zainstalowany - Częsty błąd!: sprawdź edytowane linijki tekstu w plikach wymagających ingerencji przez Notatnik (Korzystaj z instrukcji!)
	Możliwe że współpracuje tylko z originalną, pudełkową wersją, zaktualizowaną do 1.03
	Może nie być kompatybilny z innymi modyfikacjami
	Częsty bug!: Gdy wybrałeś już zmodyfikowany samochód, nie klikaj na ekran w innym miejscu niż przyciski!
 - Jeśli projekt lub strona SJ2Revive zostaną zmienione, możesz skontaktować się z twórcami (o ile żyją i chce im się angażować w SJ2):
YouTube:( @Qwertyuiop123: https://www.youtube.com/@Qwertyuiop-123 oraz @Zordon: https://www.youtube.com/@zordon3582 ), aby zdobyć zawartość
 - W celu uzyskania pomocy w tworzeniu modów do Symulatora Jazdy 2 możesz skontaktować się z twórcami SJ2Revive oraz na Forum Ogre (pliki .mesh)
 - Gra nie odwzorowuje faktycznego modelu jazdy prawdziwym samochodem oraz warunków drogowych, a przepisy ruchu drogowago mogą być przestarzałe, 
nie próbuj więc naśladować manewrów wykonywanych w grzę, gdyż może to być niebezpieczne, a nawet zagrażać życiu lub zdrowiu!



by Qwertuiop123 (27/01/2023)
